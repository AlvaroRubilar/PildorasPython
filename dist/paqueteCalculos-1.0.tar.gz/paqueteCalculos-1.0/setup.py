from setuptools import setup
setup(
    name="paqueteCalculos",
    version="1.0",
    description="Paquete de redondeo y potncia",
    author="Alvaro",
    author_email="alvaro.rubilar@usach.cl",
    packages=["calculos","calculos.redondeoPotencias"]
)