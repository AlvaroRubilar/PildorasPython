def sumar(op1, op2):
    print("El resultado de la suma es: ", op1 + op2)


def restar(op1, op2):
    print("El resultado de la resta es: ", op1 - op2)


def multiplicar(op1, op2):
    print("El resultado de la multiplicación es: ", op1 * op2)


def potencia(base, exponente):
    print("El resultado de la potencia es:", base ** exponente)


def division(dividendo, divisor):
    print("El resultado de la división es: ", dividendo / divisor)


def redondeo(numero):
    print("El resultado al redondear es: ", round(numero))
