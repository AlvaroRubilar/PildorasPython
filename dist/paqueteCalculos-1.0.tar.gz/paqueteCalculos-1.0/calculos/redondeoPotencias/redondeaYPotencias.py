def redondeo(numero):
    print("El resultado al redondear es: ", round(numero))
def potencia(base, exponente):
    print("El resultado de la potencia es:", base ** exponente)